public class BirthEvent
{
    public int x, y, dx, dy;

    public BirthEvent( int xx, int yy, int ddx, int ddy)
    {
    	x = xx;
		y = yy;
		dx = ddx;
		dy = ddy;
    }
}