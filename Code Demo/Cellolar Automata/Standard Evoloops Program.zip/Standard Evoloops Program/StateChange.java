// For CA updating

public class StateChange
{
    public int x, y;
    public int nextState;

    public StateChange( int xx, int yy, int nn)
    {
    	x = xx;
		y = yy;
		nextState = nn;
    }
}