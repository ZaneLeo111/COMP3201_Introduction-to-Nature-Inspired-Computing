import java.io.*;
import java.util.*;

class CellUpdate
{
    public int x, y;

    public CellUpdate(int xx, int yy)
    {
    	x = xx;
		y = yy;
    }
}