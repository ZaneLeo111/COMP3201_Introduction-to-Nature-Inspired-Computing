public class DeathEvent
{
    public int x, y;

    public DeathEvent( int xx, int yy)
    {
    	x = xx;
		y = yy;
    }
}