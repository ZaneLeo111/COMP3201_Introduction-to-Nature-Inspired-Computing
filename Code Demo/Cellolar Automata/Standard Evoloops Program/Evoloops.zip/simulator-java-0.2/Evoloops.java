//
//   "Evoloops.java"
//
//   Evoloop simulator with event-driven birth/death detection mechanisms
//   Java application version 0.2
//   (CA updating algorithm much improved 09/22/2004)
//
//   Note:
//     The detection algorithms used in this application were originally
//     developed by Chris Salzberg and Antony Antony at the Section
//     Computational Science, University of Amsterdam, the Netherlands.
//
//     This application does not include features of genealogy tracing
//     that were used to produce the results presented in our publications.
//
//     Evoloop Website:       http://complex.hc.uec.ac.jp/sayama/sdsr/
//     Artis Project Website: http://artis.phenome.org/
//
//
//   Any questions or comments should be addressed to:
//     Dr. Hiroki Sayama
//     Associate Professor
//     Department of Human Communication
//     University of Electro-Communications
//     1-5-1 Chofugaoka
//     Chofu Tokyo 182-8585 JAPAN
//     sayama@cx.hc.uec.ac.jp
//
//   Copyright (c) 2004 by Hiroki Sayama
//   All rights reserved
//


import java.awt.*;
import java.awt.event.*;
import java.awt.Graphics;
import java.io.*;
import java.util.*;


// Canvas for graphical display of CA configuration

class CellularAutomataCanvas extends Canvas {
    public CellularAutomata caller;
    public Image buffer = null;
    public Graphics buffer_g = null;
    public int canvasWidth, canvasHeight;

    CellularAutomataCanvas(CellularAutomata obj, int cx, int cy) {
	caller = obj;
	canvasWidth = cx;
	canvasHeight = cy;
	setSize(canvasWidth, canvasHeight);
	setBackground(Color.white);
    }
  
    public void createBuffer() {
	buffer = createImage(caller.width, caller.height);
	buffer_g = buffer.getGraphics();
	buffer_g.setColor(caller.cellColor[caller.QUIESCENT]);
	buffer_g.fillRect(0, 0, caller.width, caller.height);
    }

    public void paint(Graphics g) {
	if (buffer == null) createBuffer();
	g.drawImage(buffer, 0, 0, canvasWidth, canvasHeight, this);
    }

    public void update(Graphics g) {
	paint(g);
    }
}


// Main Frame, including CA updating scheme and event detection mechanisms

class CellularAutomata extends Frame implements ActionListener {
    public int width = 200;
    public int height = 200;
    public int[][] cell;
    public int[][] scan;
    public StateChangeStack stateChanges;
    public CellUpdateStack cellUpdates;

    public SpeciesDatabase population;
    public BirthEventStack birthEvents;
    public DeathEventStack deathEvents;

    public static final int QUIESCENT = 0;
    public static final int NOT_OCCUPIED = -1;
    public static Color[] cellColor = {Color.black, Color.blue, Color.red,
				       Color.magenta, Color.green, Color.cyan,
				       Color.yellow, Color.white, Color.gray};

    public static Color[] scanColor = {
	new Color(255, 255, 128),
	new Color(255, 128, 255),
	new Color(255, 128, 128),
	new Color(128, 255, 255),
	new Color(128, 255, 128),
	new Color(128, 128, 255),
	new Color(255, 255, 192),
	new Color(255, 192, 255),
	new Color(255, 192, 192),
	new Color(255, 192, 128),
	new Color(255, 128, 192),
	new Color(192, 255, 255),
	new Color(192, 255, 192),
	new Color(192, 255, 128),
	new Color(192, 192, 255),
	new Color(192, 192, 192),
	new Color(192, 192, 128),
	new Color(192, 128, 255),
	new Color(192, 128, 192),
	new Color(192, 128, 128),
	new Color(128, 255, 192),
	new Color(128, 192, 255),
	new Color(128, 192, 192),
	new Color(128, 192, 128),
	new Color(128, 128, 192)
	    };

    public Panel simulator;
    public CellularAutomataCanvas cnv;
    public Panel console;
    public Panel variousSettings;
    public Label timeDisplay;
    public TextField intervalField;
    public TextField spaceSizeField;
    public TextField ancestorField;
    public Panel buttons;
    public Button startStop, step, reset;
    public Panel analysisResultPanel;
    public TextArea analysisResult;

    public boolean pause, oneStep, resetRequest;
    public long time;
    public int interval;

    CellularAutomata(int cx, int cy) {
	super("Evoloops");

	addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e) {
		    System.exit(0);
		}
	    });

	setLayout(new BorderLayout(10, 10));

	simulator = new Panel();
	simulator.setLayout(new BorderLayout(10, 10));
	simulator.add(cnv = new CellularAutomataCanvas(this, cx, cy), BorderLayout.CENTER);

	console = new Panel();
	console.setLayout(new GridLayout(2, 1));

	buttons = new Panel();
	buttons.setLayout(new GridLayout(1, 5));
	buttons.add(new Label("Time: ", Label.RIGHT));
	buttons.add(timeDisplay = new Label("0", Label.LEFT));
	buttons.add(startStop = new Button("Start"));
	startStop.addActionListener(this);
	buttons.add(step = new Button("Step"));
	step.addActionListener(this);
	buttons.add(reset = new Button("Reset"));
	reset.addActionListener(this);
	console.add(buttons);

	variousSettings = new Panel();
	variousSettings.setLayout(new GridLayout(1, 6));
	variousSettings.add(new Label("Interval: ", Label.RIGHT));
	variousSettings.add(intervalField = new TextField("100"));
	intervalField.addActionListener(this);
	variousSettings.add(new Label("Space Size: ", Label.RIGHT));
	variousSettings.add(spaceSizeField = new TextField("200"));
	spaceSizeField.addActionListener(this);
	variousSettings.add(new Label("Ancestor: ", Label.RIGHT));
	variousSettings.add(ancestorField = new TextField("13-2.img"));
	ancestorField.addActionListener(this);
	console.add(variousSettings);

	simulator.add(console, BorderLayout.SOUTH);
	add(simulator, BorderLayout.WEST);

	analysisResultPanel = new Panel();
	analysisResultPanel.setLayout(new GridLayout(1, 1));
	
	analysisResultPanel.add(analysisResult = new TextArea("", 10, 10));
	analysisResult.setEditable(false);
	add(analysisResultPanel, BorderLayout.CENTER);

	stateChanges = new StateChangeStack();

	population = new SpeciesDatabase();
	birthEvents = new BirthEventStack();
	deathEvents = new DeathEventStack();
	outputPopulation();

	setSize(cx + 300, cy + 100);

	show();

	if (cnv.buffer == null) cnv.createBuffer();
    }

    public void createNewCells(int x, int y) {
	width = x;
	height = y;
	cnv.createBuffer();
	cell = new int[width][height];
	scan = new int[width][height];
	cellUpdates = new CellUpdateStack(width, height);
	clearCellularAutomata();
    }

    public void actionPerformed(ActionEvent e) {
	if (e.getSource() == startStop) {
	    if (pause) {
		startStop.setLabel("Stop");
		pause = false;
		oneStep = false;
	    }
	    else {
		startStop.setLabel("Start");
		oneStep = true;
		// Consider this the same as "Step" button pressed
		// in order to execute reflectCellsToBuffer()
	    }
	}
	else if (e.getSource() == step) oneStep = true;

	else if (e.getSource() == intervalField) setInterval();

	else if ((e.getSource() == reset) ||
		 (e.getSource() == spaceSizeField) ||
		 (e.getSource() == ancestorField)) resetRequest = true;
    }

    public void setInterval() {
	int tempInterval;

	try {
	    tempInterval = Integer.parseInt(intervalField.getText());
	}
	catch (Exception ex) {
	    System.out.println("Illegal interval specified.");
	    intervalField.setText("10");
	    tempInterval = 10;
	}
	if (tempInterval < 1) {
	    System.out.println("Non-positive interval specified.");
	    intervalField.setText("1");
	    tempInterval = 1;
	}

	interval = tempInterval;
    }

    public void resetSimulation() {
	int spaceSize;
	String imageFile;
	File tempFile;

	time = 0;
	timeDisplay.setText("" + time);

	setInterval();

	startStop.setLabel("Start");
	pause = true;
	oneStep = false;
	resetRequest = false;

	try {
	    spaceSize = Integer.parseInt(spaceSizeField.getText());
	}
	catch (Exception ex) {
	    System.out.println("Illegal space size specified.");
	    spaceSizeField.setText("200");
	    spaceSize = 200;
	}
	if (spaceSize < 20) {
	    System.out.println("Too small space size specified.");
	    spaceSizeField.setText("20");
	    spaceSize = 20;
	}
	else if (spaceSize > 2000) {
	    System.out.println("Too large space size specified.");
	    spaceSizeField.setText("2000");
	    spaceSize = 2000;
	}
	width = height = spaceSize;
	createNewCells(width, height);
	stateChanges.clear();
	population.clear();
	birthEvents.clear();
	deathEvents.clear();

	imageFile = ancestorField.getText();
	tempFile = new File(imageFile);
	if (!tempFile.exists()) {
	    System.out.println("File \"" + imageFile + "\" does not exist.");
	    ancestorField.setText("13-2.img");
	    imageFile = ancestorField.getText();
	}
	putAncestor(imageFile, width / 2, height / 2);
	reflectCellsToBuffer();
	outputPopulation();
    }

    public void putAncestor(String imageFile, int x, int y) {
	String buf;
	int wd, ht, len, xx, yy, i;
	char data;
	StateChange sc;

	// Measuring the size of image

	wd = ht = 0;
	try {
	    BufferedReader br = new BufferedReader(new FileReader(imageFile));
	    while ((buf = br.readLine()) != null) {
		ht ++;
		len = buf.length();
		if (len > wd) wd = len;
	    }
	    br.close();
	}
	catch (Exception ex) {
	    System.out.println("Error: " + ex);
	    System.exit(1);
	}

	// Loading image

	x = x - wd / 2;
	y = y - ht / 2;

	if ((x < 0) || (x + wd > width) || (y < 0) || (y + ht > height)) {
	    System.out.println("Image file \"" + imageFile + "\" sticks out of the space.");
	    System.exit(1);
	}

	xx = x;
	yy = y;

	try {
	    BufferedReader br = new BufferedReader(new FileReader(imageFile));
	    while ((buf = br.readLine()) != null) {
		for (i = 0, xx = x; i < buf.length(); i ++, xx ++) {
		    data = buf.charAt(i);
		    if ((data >= '1') && (data <= '9'))
			stateChanges.push(xx, yy, (int) buf.charAt(i) - (int) '0');
		    else if ((data != ' ') && (data != '0')) {
			System.out.println("Illegal state appeared in \"" + imageFile + "\".");
			System.exit(1);
		    }
		}
		yy ++;
	    }
	    br.close();
	}
	catch (Exception ex) {
	    System.out.println("Error: " + ex);
	    System.exit(1);
	}

	while (!stateChanges.empty()) {
	    sc = stateChanges.pop();

	    x = sc.x;
	    y = sc.y;
	    cell[x][y] = sc.nextState;

	    cellUpdates.push(x, y);
	    cellUpdates.push(x > 0 ? x - 1 : width - 1, y);
	    cellUpdates.push(x < width - 1 ? x + 1 : 0, y);
	    cellUpdates.push(x, y > 0 ? y - 1 : height - 1);
	    cellUpdates.push(x, y < height - 1 ? y + 1 : 0);
	}
    }

    public int getCellState(int x, int y) {
	if (x < 0) x = width - 1;
	if (x > width - 1) x = 0;
	if (y < 0) y = height - 1;
	if (y > height - 1) y = 0;
	return cell[x][y];
    }

    public int getScanState(int x, int y) {
	if (x < 0) x = width - 1;
	if (x > width - 1) x = 0;
	if (y < 0) y = height - 1;
	if (y > height - 1) y = 0;
	return scan[x][y];
    }

    public void clearCellularAutomata() {
	int x, y;
	for (x = 0; x < width; x ++)
	    for (y = 0; y < height; y ++) {
		cell[x][y] = QUIESCENT;
		scan[x][y] = NOT_OCCUPIED;
	    }
	stateChanges.clear();
	cellUpdates.clear();
    }

    public void reflectCellsToBuffer() {
	int x, y;
	cnv.buffer_g.setColor(cellColor[QUIESCENT]);
	cnv.buffer_g.fillRect(0, 0, width, height);
	for (x = 0; x < width; x ++)
	    for (y = 0; y < height; y ++) {
		if (scan[x][y] != NOT_OCCUPIED) {// indicating living loops
		    cnv.buffer_g.setColor(scanColor[scan[x][y] % scanColor.length]);
		    cnv.buffer_g.fillRect(x, y, 1, 1);
		}
		else if (cell[x][y] != QUIESCENT) {
		    cnv.buffer_g.setColor(cellColor[cell[x][y]]);
		    cnv.buffer_g.fillRect(x, y, 1, 1);
		}
	    }
	cnv.repaint();
    }

    public void outputPopulation() {
	SpeciesPop sppop;
	analysisResult.setText("ID : size : sequence : count\n");

	for (int i = 0; i < population.length(); i ++) {
	    sppop = population.speciesPopOf(i);
	    if (sppop.pop > 0) {
		analysisResult.append("" +
				      i + " : " +
				      sppop.sp.pheno.width + "x" +
				      sppop.sp.pheno.height + " : " +
				      sppop.sp.geno.sequence + " : " +
				      sppop.pop + "\n");
	    }
	}
    }

    public void updateCellularAutomata(int[][][][][] rule) {
	int x, y, c, t, r, b, l, ns, len;
	CellUpdate cu;
	StateChange sc;
	BirthEvent be;
	DeathEvent de;
	int deadID;

	while (!cellUpdates.empty()) {
	    cu = cellUpdates.pop();

	    x = cu.x;
	    y = cu.y;

	    c = cell[x][y];
	    t = getCellState(x, y - 1);
	    r = getCellState(x + 1, y);
	    b = getCellState(x, y + 1);
	    l = getCellState(x - 1, y);
	    ns = rule[c][t][r][b][l];
	    if (c != ns) stateChanges.push(x, y, ns);

	    if ((c == 0) && (ns == 6)) {
		if ((t==1) && (r==2) && (b==5) && (l==2))
		    birthEvents.push(x, y < height-1 ? y+1 : 0 , 0, 1);
		else if ((t==2) && (r==5) && (b==2) && (l==1))
		    birthEvents.push(x < width-1 ? x+1 : 0, y, 1, 0);
		else if ((t==5) && (r==2) && (b==1) && (l==2))
		    birthEvents.push(x, y > 0 ? y-1 : height-1, 0, -1);
		else if ((t==2) && (r==1) && (b==2) && (l==5))
		    birthEvents.push(x > 0 ? x-1 : width-1, y, -1, 0);
	    }

	    if ((c == 2) && (ns == 0)
		&& (scan[x][y] != NOT_OCCUPIED)) deathEvents.push(x, y);
	}

	while (!stateChanges.empty()) {
	    sc = stateChanges.pop();

	    x = sc.x;
	    y = sc.y;
	    cell[x][y] = sc.nextState;

	    cellUpdates.push(x, y);
	    cellUpdates.push(x > 0 ? x - 1 : width - 1, y);
	    cellUpdates.push(x < width - 1 ? x + 1 : 0, y);
	    cellUpdates.push(x, y > 0 ? y - 1 : height - 1);
	    cellUpdates.push(x, y < height - 1 ? y + 1 : 0);
	}


	while (!birthEvents.empty()) {
	    be = birthEvents.pop();

	    int xx, yy, dx, dy, tempdx, w, h, wcheck, hcheck;
	    String seq = "";

	    xx = be.x;
	    yy = be.y;
	    dx = be.dx;
	    dy = be.dy;

	    w = 0;
	    while (true) {
		seq += ("" + cell[xx][yy]);
		w ++;
		xx += dx; if (xx < 0) xx = width - 1; if (xx > width - 1) xx = 0;
		yy += dy; if (yy < 0) yy = height - 1; if (yy > height - 1) yy = 0;
		if (getCellState(xx + dy, yy - dx) != 2) break;
	    }
	    w --;

	    tempdx = dx;
	    dx = dy;
	    dy = -tempdx;

	    h = 0;
	    while (true) {
		seq += ("" + cell[xx][yy]);
		h ++;
		xx += dx; if (xx < 0) xx = width - 1; if (xx > width - 1) xx = 0;
		yy += dy; if (yy < 0) yy = height - 1; if (yy > height - 1) yy = 0;
		if (getCellState(xx + dy, yy - dx) != 2) break;
	    }
	    h --;

	    tempdx = dx;
	    dx = dy;
	    dy = -tempdx;

	    wcheck = 0;
	    while (true) {
		seq += ("" + cell[xx][yy]);
		wcheck ++;
		xx += dx; if (xx < 0) xx = width - 1; if (xx > width - 1) xx = 0;
		yy += dy; if (yy < 0) yy = height - 1; if (yy > height - 1) yy = 0;
		if (getCellState(xx + dy, yy - dx) != 2) break;
	    }
	    wcheck --;

	    tempdx = dx;
	    dx = dy;
	    dy = -tempdx;

	    hcheck = 0;
	    while (true) {
		seq += ("" + cell[xx][yy]);
		hcheck ++;
		xx += dx; if (xx < 0) xx = width - 1; if (xx > width - 1) xx = 0;
		yy += dy; if (yy < 0) yy = height - 1; if (yy > height - 1) yy = 0;
		if (getCellState(xx + dy, yy - dx) != 2) break;
	    }
	    hcheck --;

	    Species sp = new Species(w, h, seq);
	    if ((w == wcheck) && (h == hcheck) && (sp.geno.sequence != null)) {

		population.birth(sp);
		int bornID = population.indexOf(sp);

		xx -= dx; if (xx < 0) xx = width - 1; if (xx > width - 1) xx = 0;
		yy -= dy; if (yy < 0) yy = height - 1; if (yy > height - 1) yy = 0;

		tempdx = dx;
		dx = dy;
		dy = -tempdx;

		xx += dx; if (xx < 0) xx = width - 1; if (xx > width - 1) xx = 0;
		yy += dy; if (yy < 0) yy = height - 1; if (yy > height - 1) yy = 0;
		
		int corner = 0;
		while(corner < 4) {
		    scan[xx][yy] = bornID;
		    if (getCellState(xx + dx, yy + dy) != 2) {
			tempdx = dx;
			dx = dy;
			dy = -tempdx;
			corner ++;
		    }
		    else {
			xx += dx; if (xx < 0) xx = width - 1; if (xx > width - 1) xx = 0;
			yy += dy; if (yy < 0) yy = height - 1; if (yy > height - 1) yy = 0;
		    }
		}
	    }
	}

	while (!deathEvents.empty()) {
	    de = deathEvents.pop();
	    if ((deadID = scan[de.x][de.y]) != NOT_OCCUPIED) {
		population.death(deadID);
		Stack st = new Stack();
		st.push(de);
		while(!st.empty()) {
		    de = (DeathEvent) st.pop();
		    scan[de.x][de.y] = NOT_OCCUPIED;
		    if (getScanState(de.x, de.y - 1) != NOT_OCCUPIED)
			st.push(new DeathEvent(de.x, de.y > 0 ? de.y-1 : height-1));
		    if (getScanState(de.x + 1, de.y) != NOT_OCCUPIED)
			st.push(new DeathEvent(de.x < width-1 ? de.x+1 : 0, de.y));
		    if (getScanState(de.x, de.y + 1) != NOT_OCCUPIED)
			st.push(new DeathEvent(de.x, de.y < height-1 ? de.y+1 : 0));
		    if (getScanState(de.x - 1, de.y) != NOT_OCCUPIED)
			st.push(new DeathEvent(de.x > 0 ? de.x-1 : width-1, de.y));
		}
	    }
	}
    }

    public void simulation(int[][][][][] rule) {
	while (true) {
	    if (resetRequest) resetSimulation();
	    if ((!pause) || oneStep) {
		updateCellularAutomata(rule);
		time ++;
		timeDisplay.setText("" + time);
		if (oneStep || (time % interval == 0)) {
		    reflectCellsToBuffer();
		    outputPopulation();
		}
		if (oneStep) {
		    startStop.setLabel("Start");
		    pause = true;
		    oneStep = false;
		}
	    }
	}
    }
}


// For CA updating

class StateChange {
    public int x, y;
    public int nextState;

    StateChange(int xx, int yy, int nn) {
	x = xx;
	y = yy;
	nextState = nn;
    }
}


class StateChangeStack {
    private Stack changeStack;

    StateChangeStack() {
	changeStack = new Stack();
	clear();
    }

    public void clear() {
	changeStack.clear();
    }

    public boolean empty() {
	return changeStack.empty();
    }

    public void push(int x, int y, int nextState) {
	changeStack.push(new StateChange(x, y, nextState));
    }

    public StateChange pop() {
	if (changeStack.empty()) return null;
	else return (StateChange) changeStack.pop();
    }
}


class CellUpdate {
    public int x, y;

    CellUpdate(int xx, int yy) {
	x = xx;
	y = yy;
    }
}

class CellUpdateStack {
    private Stack updateStack;
    private boolean[][] inStack;
    private int spacex, spacey;

    CellUpdateStack(int x, int y) {
	updateStack = new Stack();
	inStack = new boolean[x][y];
	spacex = x;
	spacey = y;
	clear();
    }

    public void clear() {
	updateStack.clear();
	for (int i = 0; i < spacex; i ++)
	    for (int j = 0; j < spacey; j ++)
		inStack[i][j] = false;
    }

    public boolean empty() {
	return updateStack.empty();
    }

    public void push(int x, int y) {
	if (!inStack[x][y]) {
	    inStack[x][y] = true;
	    updateStack.push(new CellUpdate(x, y));
	}
    }

    public CellUpdate pop() {
	CellUpdate cu;

	if (updateStack.empty()) return null;
	else {
	    cu = (CellUpdate) updateStack.pop();
	    inStack[cu.x][cu.y] = false;
	    return cu;
	}
    }
}


// For maintaining species database and birth/death detection

class Phenotype {
    public int width, height;

    Phenotype(int w, int h) {
	width = w;
	height = h;
    }

    public boolean equals(Phenotype another) {
	if ((width == another.width) && (height == another.height)) return true;
	else return false;
    }
}

class Genotype {
    public String rawData;
    public String sequence;

    Genotype(String raw) {
	rawData = raw;
	compressRawData();
    }

    public boolean equals(Genotype another) {
	if ((sequence == null) || (another.sequence == null)) return false;
	if (sequence.equals(another.sequence)) return true;
	else return false;
    }

    private void compressRawData() {
	int i;

	sequence = "";
	for (i = 0; i < rawData.length(); i ++) {
	    if (rawData.regionMatches(i, "1", 0, 1)) sequence += "C";
	    else if (rawData.regionMatches(i, "041", 0, 3)) {
		sequence += "T";
		i += 2;
	    }
	    else if (rawData.regionMatches(i, "071", 0, 3)) {
		sequence += "G";
		i += 2;
	    }
	    else {
		sequence = null;
		break;
	    }
	}
    }
}


class Species {
    public Phenotype pheno;
    public Genotype geno;

    Species (Phenotype p, Genotype g) {
	pheno = p;
	geno = g;
    }

    Species (int w, int h, String raw) {
	pheno = new Phenotype(w, h);
	geno = new Genotype(raw);
    }

    public boolean equals(Species another) {
	if ((pheno.equals(another.pheno)) && (geno.equals(another.geno))) return true;
	else return false;
    }
}


class SpeciesPop {
    public Species sp;
    public int pop;

    SpeciesPop(Species s, int p) {
	sp = s;
	pop = p;
    }
}


class SpeciesDatabase {
    private ArrayList database;

    SpeciesDatabase() {
	database = new ArrayList();
	clear();
    }

    public void clear() {
	database.clear();
    }

    public int length() {
	return database.size();
    }

    public SpeciesPop speciesPopOf(int i) {
	if ((i < 0) || (i >= database.size())) return null;
	else return (SpeciesPop) database.get(i);
    }

    public int indexOf(Species s) {
	int i;

	for (i = 0; i < database.size(); i ++)
	    if (s.equals(((SpeciesPop) database.get(i)).sp)) return i;
	
	database.add(new SpeciesPop(s, 0));
	return i;
    }

    public void birth(Species s) {
	SpeciesPop sppop = null;

	for (int i = 0; i < database.size(); i ++) {
	    sppop = (SpeciesPop) database.get(i);
	    if (s.equals(sppop.sp)) break;
	    sppop = null;
	}

	if (sppop == null) database.add(sppop = new SpeciesPop(s, 0));

	sppop.pop ++;
    }

    /*
    public void birth(int i) {
	SpeciesPop sppop = (SpeciesPop) database.get(i);
	sppop.pop ++;
    }
    */

    /*
    public void death(Species s) {
	SpeciesPop sppop = null;

	for (int i = 0; i < database.size(); i ++) {
	    sppop = (SpeciesPop) database.get(i);
	    if (s.equals(sppop.sp)) break;
	    sppop = null;
	}

	if (sppop == null) database.add(sppop = new SpeciesPop(s, 0));

	sppop.pop --;

	if (sppop.pop < 0) {
	    System.out.println("Non-existent species died!?");
	    System.exit(1);
	}
    }
    */

    public void death(int i) {
	SpeciesPop sppop = (SpeciesPop) database.get(i);
	sppop.pop --;
	if (sppop.pop < 0) {
	    System.out.println("Non-existent species died!?");
	    System.exit(1);
	}
    }
}


class BirthEvent {
    public int x, y, dx, dy;

    BirthEvent(int xx, int yy, int ddx, int ddy) {
	x = xx;
	y = yy;
	dx = ddx;
	dy = ddy;
    }
}


class BirthEventStack {
    private Stack eventStack;

    BirthEventStack() {
	eventStack = new Stack();
	clear();
    }

    public void clear() {
	eventStack.clear();
    }

    public boolean empty() {
	return eventStack.empty();
    }

    public void push(int x, int y, int dx, int dy) {
	eventStack.push(new BirthEvent(x, y, dx, dy));
    }

    public BirthEvent pop() {
	if (eventStack.empty()) return null;
	else return (BirthEvent) eventStack.pop();
    }
}


class DeathEvent {
    public int x, y;

    DeathEvent(int xx, int yy) {
	x = xx;
	y = yy;
    }
}


class DeathEventStack {
    private Stack eventStack;

    DeathEventStack() {
	eventStack = new Stack();
	clear();
    }

    public void clear() {
	eventStack.clear();
    }

    public boolean empty() {
	return eventStack.empty();
    }

    public void push(int x, int y) {
	eventStack.push(new DeathEvent(x, y));
    }

    public DeathEvent pop() {
	if (eventStack.empty()) return null;
	else return (DeathEvent) eventStack.pop();
    }
}


// Main application

class Evoloops {
    static int canvasWidth = 600;
    static int canvasHeight = 600;
    static CellularAutomata ca;
    static int[][][][][] rule = new int[9][9][9][9][9];

    public static void defineRules(String ruleFile, boolean introduceDissolver) {
	String buf;
	int a, b, c, d, e, f;

	for (a = 0; a <= 8; a ++)
	    for (b = 0; b <= 8; b ++)
		for (c = 0; c <= 8; c ++)
		    for (d = 0; d <= 8; d ++)
			for (e = 0; e <= 8; e ++)
			    rule[a][b][c][d][e] = -1;
	
	try {
	    BufferedReader br = new BufferedReader(new FileReader(ruleFile));
	    while ((buf = br.readLine()) != null) {
		a = (int) buf.charAt(0) - (int) '0';
		b = (int) buf.charAt(1) - (int) '0';
		c = (int) buf.charAt(2) - (int) '0';
		d = (int) buf.charAt(3) - (int) '0';
		e = (int) buf.charAt(4) - (int) '0';
		f = (int) buf.charAt(5) - (int) '0';
		rule[a][b][c][d][e] = f;
		rule[a][c][d][e][b] = f;
		rule[a][d][e][b][c] = f;
		rule[a][e][b][c][d] = f;
	    }
	    br.close();
	}
	catch (Exception ex) {
	    System.out.println("Error: " + ex);
	    System.exit(1);
	}

	if (!introduceDissolver) return;

	// Defining rules related to state '8'

	for (a = 0; a <= 8; a ++)
	    for (b = 0; b <= 8; b ++)
		for (c = 0; c <= 8; c ++)
		    for (d = 0; d <= 8; d ++)
			for (e = 0; e <= 8; e ++)
			    if (rule[a][b][c][d][e] == -1) {

				if (a == 8) rule[a][b][c][d][e] = 0;

				else if ((b == 8) || (c == 8) || (d == 8) || (e == 8))
				    switch(a) {

				    case 0:
				    case 1:
					if (((b >= 2) && (b <= 7)) || ((c >= 2) && (c <= 7)) ||
					    ((d >= 2) && (d <= 7)) || ((e >= 2) && (e <= 7)))
					    rule[a][b][c][d][e] = 8;
					else rule[a][b][c][d][e] = a;
					break;

				    case 2:
				    case 3:
				    case 5:
					rule[a][b][c][d][e] = 0;
					break;

				    case 4:
				    case 6:
				    case 7:
					rule[a][b][c][d][e] = 1;
					break;
				    }
			    }

	// Defining all undefined rules

	for (a = 0; a <= 8; a ++)
	    for (b = 0; b <= 8; b ++)
		for (c = 0; c <= 8; c ++)
		    for (d = 0; d <= 8; d ++)
			for (e = 0; e <= 8; e ++) 
			    if (rule[a][b][c][d][e] == -1) {
				if (a == 0) rule[a][b][c][d][e] = 0;
				else rule[a][b][c][d][e] = 8;
			    }
    }

    public static void main (String args[]) {
	defineRules("rule_evolvable", true);

	ca = new CellularAutomata(canvasWidth, canvasHeight);
	ca.resetSimulation();
	ca.simulation(rule);
    }
}
